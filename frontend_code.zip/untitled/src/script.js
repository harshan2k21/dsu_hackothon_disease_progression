function handleFileChange(event) {
  const file = event.target.files[0];
  const fileInfo = document.getElementById("file-info");
  if (file && file.type === "text/csv") {
    fileInfo.textContent = `Selected file: ${file.name}`;
  } else {
    fileInfo.textContent = "Please select a valid CSV file.";
  }
}

function predict() {
  const file = document.getElementById("csv-upload").files[0];
  if (file && file.type === "text/csv") {
    alert(`Predicting based on the file: ${file.name}`);
    // Add further processing logic here
  } else {
    alert("Please upload a valid CSV file first.");
  }
}

function reset() {
  document.getElementById("csv-upload").value = "";
  document.getElementById("file-info").textContent = "";
}
